import heapq


def dijkstra(graph, start):
    priority_queue = [(0, start)]
    distances = {node: float('inf') for node in graph}
    distances[start] = 0

    while priority_queue:
        current_distance, current_node = heapq.heappop(priority_queue)

        if current_distance > distances[current_node]:
            continue

        for neighbor, weight in graph[current_node].items():
            distance = current_distance + weight

            if distance < distances[neighbor]:
                distances[neighbor] = distance
                heapq.heappush(priority_queue, (distance, neighbor))

    return distances


def get_user_input():
    graph = {}
    num_nodes = int(input("Enter the number of nodes: "))

    for _ in range(num_nodes):
        node = input("Enter node name: ")
        graph[node] = {}

    num_edges = int(input("Enter the number of edges: "))

    for _ in range(num_edges):
        u, v, w = input("Enter edge (start end weight): ").split()
        w = int(w)
        graph[u][v] = w
        graph[v][u] = w

    return graph


graph = get_user_input()
start_node = input("Enter the starting node: ")
shortest_paths = dijkstra(graph, start_node)
print(f"\nShortest distances from node {start_node}:")
for node, distance in shortest_paths.items():
    print(f"{node}: {distance}")
