import math


def encrypt_transposition(plain_text, key, dummy_char='x'):
    # Replace spaces with the dummy character
    plain_text = plain_text.replace(" ", dummy_char)

    cipher_text = [''] * key
    for i in range(key):
        for j in range(i, len(plain_text), key):
            cipher_text[i] += plain_text[j]
    return ''.join(cipher_text)


def decrypt_transposition(cipher_text, key, dummy_char='x'):
    num_cols = math.ceil(len(cipher_text) / key)
    num_rows = key
    num_empty = (num_cols * num_rows) - len(cipher_text)

    plain_text = [''] * num_cols
    col, row = 0, 0

    for char in cipher_text:
        plain_text[col] += char
        col += 1
        if col == num_cols or (col == num_cols - 1 and row >= num_rows - num_empty):
            col = 0
            row += 1

    # Remove the dummy character after decryption
    return ''.join(plain_text).replace(dummy_char, ' ')


# Taking user input
plain_text = input("Enter the text to encrypt: ")
key = int(input("Enter the key (integer value): "))

# Encrypting the text
encrypted_text = encrypt_transposition(plain_text, key)
print("Encrypted Text:", encrypted_text)

# Decrypting the text
decrypted_text = decrypt_transposition(encrypted_text, key)
print("Decrypted Text:", decrypted_text)
