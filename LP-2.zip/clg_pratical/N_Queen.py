# Check if placing a queen at (row, col) is safe
def is_safe(board, row, col):
    for i in range(row):
        if board[i] == col or abs(board[i] - col) == row - i:
            return False
    return True

# Backtracking solution for n-Queens problem


def solve_nqueens_backtracking(board, row, n):
    # If all queens are placed
    if row == n:
        return True

    for col in range(n):
        if is_safe(board, row, col):
            board[row] = col
            if solve_nqueens_backtracking(board, row + 1, n):
                return True
            board[row] = -1  # Backtrack
    return False

# Branch and Bound - Heuristic to count conflicts


def bound(board, row, n):
    conflicts = 0
    for i in range(row):
        for j in range(i + 1, row):
            if board[i] == board[j] or abs(board[i] - board[j]) == j - i:
                conflicts += 1
    return conflicts


# Branch and Bound solution for n-Queens problem
def solve_nqueens_branch_and_bound(board, row, n, best_solution):
    if row == n:
        best_solution[0] = board[:]
        return True

    sorted_columns = list(range(n))
    sorted_columns.sort(key=lambda col: bound(board, row, n))  # Sort columns by conflicts

    for col in sorted_columns:
        if is_safe(board, row, col):
            board[row] = col
            if bound(board, row, n) == 0:  # No conflicts found
                if solve_nqueens_branch_and_bound(board, row + 1, n, best_solution):
                    return True
            board[row] = -1
    return False


# Print the board
def print_board(board, n):
    for row in range(n):
        row_str = ""
        for col in range(n):
            if board[row] == col:
                row_str += "Q "
            else:
                row_str += "* "
        print(row_str)
    print("\n")


# Function to solve n-Queens problem using Backtracking
def nqueens_backtracking(n):
    board = [-1] * n
    if solve_nqueens_backtracking(board, 0, n):
        print("Backtracking Solution found:")
        print_board(board, n)
    else:
        print("No solution exists for Backtracking.\n")


# Function to solve n-Queens problem using Branch and Bound
def nqueens_branch_and_bound(n):
    board = [-1] * n
    best_solution = [None]
    if solve_nqueens_branch_and_bound(board, 0, n, best_solution):
        print("Branch and Bound Solution found:")
        print_board(best_solution[0], n)
    else:
        print("No solution exists for Branch and Bound.\n")


# Solve for 8-Queens problem using both approaches
print("Solving 8-Queens Problem using Backtracking:")
nqueens_backtracking(8)

print("Solving 8-Queens Problem using Branch and Bound:")
nqueens_branch_and_bound(8)
