import heapq


def prims_algorithm(vertices, graph):
    mst = []
    visited = set()
    min_heap = [(0, 0, -1)]
    total_weight = 0

    while len(visited) < vertices:
        weight, vertex, parent = heapq.heappop(min_heap)

        if vertex not in visited:
            visited.add(vertex)
            total_weight += weight
            if parent != -1:
                mst.append((parent, vertex, weight))

            for neighbor, edge_weight in graph[vertex]:
                if neighbor not in visited:
                    heapq.heappush(min_heap, (edge_weight, neighbor, vertex))

    return mst, total_weight


vertices = int(input("Enter the number of vertices: "))
edges = int(input("Enter the number of edges: "))

graph = {i: [] for i in range(vertices)}

print("\nEnter the edges in the format: vertex1 vertex2 weight")
for _ in range(edges):
    u, v, w = map(int, input().split())
    graph[u].append((v, w))
    graph[v].append((u, w))

mst, total_weight = prims_algorithm(vertices, graph)

print("\nMinimum Spanning Tree (Prim's Algorithm):")
for u, v, w in mst:
    print(f"Edge {u} - {v}, Weight: {w}")
print(f"Total Weight of MST: {total_weight}")
