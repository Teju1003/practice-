import heapq


class Graph:
    def __init__(self):
        self.graph = {}  # Adjacency list
        self.heuristics = {}  # Heuristic values
            
    def add_edge(self, node, neighbor, cost):
        if node not in self.graph:
            self.graph[node] = []
        self.graph[node].append((neighbor, cost))
        
    def set_heuristics(self, heuristics):
        self.heuristics = heuristics  # Assign heuristic values
        
    def astar(self, start, goal):
        open_list = []
        heapq.heappush(open_list, (0, start))  # (f(n), node)
        g_costs = {start: 0}
        came_from = {}
        while open_list:
            _, current = heapq.heappop(open_list)
            if current == goal:
                path = []
                while current in came_from:
                    path.append(current)
                    current = came_from[current]
                path.append(start)
                return path[::-1]  # Return reversed path
            for neighbor, cost in self.graph.get(current, []):
                g_new = g_costs[current] + cost
                if neighbor not in g_costs or g_new < g_costs[neighbor]:
                    g_costs[neighbor] = g_new
                    f_new = g_new + self.heuristics.get(neighbor, 0)
                    heapq.heappush(open_list, (f_new, neighbor))
                    came_from[neighbor] = current
        return None  # No path found


# Get user input for graph
g = Graph()
num_edges = int(input("Enter the number of edges: "))
print("Enter edges in the format: node1 node2 cost")
for _ in range(num_edges):
    node1, node2, cost = input().split()
    cost = int(cost)
    g.add_edge(node1, node2, cost)
    g.add_edge(node2, node1, cost)  # Assuming an undirected graph

# Get heuristic values
num_nodes = int(input("Enter the number of nodes: "))
heuristics = {}
print("Enter heuristic values in the format: node heuristic_value")
for _ in range(num_nodes):
    node, h_value = input().split()
    heuristics[node] = int(h_value)

g.set_heuristics(heuristics)

# Get start and goal nodes
start = input("Enter the start node: ")
goal = input("Enter the goal node: ")

# Run A* search
path = g.astar(start, goal)

# Output the result
if path:
    print("Path found:", path)
else:
    print("No path found.")
