from collections import defaultdict


def dfs_rec(adj, visited, s):
    # Mark the current vertex as visited
    visited[s] = True

    # Print the current vertex
    print(s, end=" ")

    # Recursively visit all adjacent vertices
    for neighbor in adj[s]:
        if not visited[neighbor]:
            dfs_rec(adj, visited, neighbor)


def dfs(adj, source, V):
    # Initialize the visited list
    visited = [False] * V

    # Check if the source vertex is valid
    if source >= V or source < 0:
        print(f"Error: Source vertex {source} is out of bounds (0 to {V-1}).")
        return

    print("DFS Traversal:")
    dfs_rec(adj, visited, source)


def add_edge(adj, s, t):
    # Add edge from s to t
    adj[s].append(t)
    adj[t].append(s)


if __name__ == "__main__":
    # Input the number of vertices and edges
    V = int(input("Enter the number of vertices: "))
    E = int(input("Enter the number of edges: "))

    # Create the adjacency list
    adj = defaultdict(list)

    print("Enter the edges (source and destination, 0-based indexing):")
    for _ in range(E):
        s, t = map(int, input().split())
        if s < 0 or s >= V or t < 0 or t >= V:
            print(f"Error: Edge ({s}, {t}) contains vertices out of bounds (0 to {V-1}).")
            continue
        add_edge(adj, s, t)

    # Input the source vertex for DFS
    source = int(input("Enter the source vertex for DFS: "))

    # Perform DFS traversal
    dfs(adj, source, V)
