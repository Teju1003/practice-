str_value = "Hello World"

print("AND with 127")
print("".join(chr(ord(c) & 127)for c in str_value))

print("OR with 127")
print("".join(chr(ord(c) ^ 127)for c in str_value))
