import random
from sympy import isprime, mod_inverse, gcd


# Function to get a valid prime number from the user
def get_user_prime(prompt):
    while True:
        try:
            num = int(input(prompt))
            if num < 2:
                print("Number must be greater than 1.")
                continue
            if not isprime(num):
                print("That's not a prime number. Try again.")
            else:
                return num
        except ValueError:
            print("Invalid input. Please enter an integer.")


# Function to choose a valid public exponent e
def choose_e(phi_n):
    possible_e_values = [3, 5, 17, 257, 65537]
    random.shuffle(possible_e_values)

    for e in possible_e_values:
        if gcd(e, phi_n) == 1:
            return e

    while True:
        e = random.randrange(3, phi_n, 2)
        if gcd(e, phi_n) == 1:
            return e


# Function to generate RSA key pair using user input
def generate_rsa_keys():
    print("Enter two distinct prime numbers:")
    p = get_user_prime("Enter prime number p: ")
    while True:
        q = get_user_prime("Enter prime number q: ")
        if q == p:
            print("p and q must be different. Enter a different q.")
        else:
            break

    n = p * q
    phi_n = (p - 1) * (q - 1)

    e = choose_e(phi_n)
    d = mod_inverse(e, phi_n)

    return (p, q, n, e, d)


# RSA Encryption
def rsa_encrypt(plaintext, e, n):
    return [pow(ord(char), e, n) for char in plaintext]


# RSA Decryption
def rsa_decrypt(ciphertext, d, n):
    return ''.join(chr(pow(char, d, n)) for char in ciphertext)


# Main Execution
p, q, n, e, d = generate_rsa_keys()

print("\nGenerated RSA Keys:")
print(f"Prime p: {p}")
print(f"Prime q: {q}")
print(f"Modulus n: {n}")
print(f"Public Key (e, n): ({e}, {n})")
print(f"Private Key (d, n): ({d}, {n})")

# Input message and perform encryption/decryption
plaintext = input("\nEnter a message to encrypt: ")
ciphertext = rsa_encrypt(plaintext, e, n)
print("\nEncrypted Ciphertext:", ciphertext)
decrypted_text = rsa_decrypt(ciphertext, d, n)
print("Decrypted Plaintext:", decrypted_text)
